package Topic5.Assignment3.Automobile.Twowheeler;

public abstract class Vehicle
{
    public abstract void getModelName();
    public abstract void getRegistrationNumber();
    public abstract void getOwnerName();
}
