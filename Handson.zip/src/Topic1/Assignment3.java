package Topic1;
import java.util.Scanner;

public class Assignment3
{
    public static void main(String[] args) {
        double minutesInYear = 60 * 24 * 365;

        Scanner input = new Scanner(System.in);

        System.out.println("Enter the number of minutes:");
        int minutes = input.nextInt();
        int year = minutes / 525600;
        int day = minutes / 1440;
        int remainingMinutes = day % 525600;
        System.out.println(minutes + " minutes is " + year + " years and "  +  remainingMinutes + " days ");
    }
}
