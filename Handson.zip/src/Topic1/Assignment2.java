package Topic1;

public class Assignment2
{
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        int a = -5 + 8 * 6;
        int b = (55 + 9) % 9;
        int c = 20 + -3 * 5 / 8;
        int d = 5 + 15 / 3 * 2 - 8 % 3;

        System.out.println("a=" + a + " b=" + b + " c=" + c + " d=" + d);
    }
}
