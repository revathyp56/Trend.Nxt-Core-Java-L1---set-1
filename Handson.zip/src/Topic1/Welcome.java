package Topic1;

public class Welcome
{
    public  static void main(String args[])
    {
        System.out.println("Welcome to java programming"+"\n"+"Revathy P");
    }
}
