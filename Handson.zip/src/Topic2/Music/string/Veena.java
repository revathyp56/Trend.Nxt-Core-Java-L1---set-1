package Topic2.Music.string;

import Topic2.Music.Playable;

public class Veena implements Playable
{
    public void play()
    {
        System.out.println("Violin is being played");
    }
}
