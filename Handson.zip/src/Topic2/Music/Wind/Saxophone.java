package Topic2.Music.Wind;

import Topic2.Music.Playable;

public class Saxophone implements Playable
{
    public void play()
    {
        System.out.println("Saxophone is being played");
    }
}
