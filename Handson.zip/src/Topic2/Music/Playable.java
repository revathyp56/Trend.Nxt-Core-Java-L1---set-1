package Topic2.Music;

public interface Playable
{
    public void play();
}
